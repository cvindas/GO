# GOLANG REST API SIMPLE

# Package
* gorilla/mux: `go get github.com/gorilla/mux`
* comileDaemon: `go get github.com/githubnemo/CompileDaemon`