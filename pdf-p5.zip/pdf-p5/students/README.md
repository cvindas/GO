# Student Examples

The following are example implementations submitted by students/gophers learning from this course.

The primary purposes of these examples are:

1. To provide example implementations to discuss and review when recording the screencasts for this course.
2. To provide a way for students to contribute to this course.
