# Config your
- GOPATH
- GOBIN

# COMMANDS
- to obtain go enviroment: `go env`
- to set enviroment
  - `export GOPATH=<path/to/directory>`
  - `export GOBIN=<path/to/directory/bin>`
- to obtain packages: `go get`
