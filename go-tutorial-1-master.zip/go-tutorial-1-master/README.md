# Go Tutorial Part 1
# A simple Static file server made with Go

### you can serve any static html, css and even JS build content using this server. Just make sure the content is in the same folder as the executable. 

## Run `go run main.go` to run the app, run `go build main.go` to build an executable file. 

### Check out the Youtube Tutorial for this [Go Program](https://youtu.be/uCR_A-Bphl0).  Here is our [Youtube Channel](https://www.youtube.com/channel/UCYqCZOwHbnPwyjawKfE21wg) Subscribe for more content.

### Check out our blog at [tensor-programming.com](http://tensor-programming.com/).

### Our [Twitter](https://twitter.com/TensorProgram) and our [facebook](https://www.facebook.com/Tensor-Programming-1197847143611799/).
